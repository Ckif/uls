#include <stdio.h>

int main(void) {
    char flags[] = {'G', 'U', 'F', 'f', 'a', 'A', 'R', 'l', '1', 'm', 'C', 'S',
    't', 'r', 'p', 'u', 'c', '@', 'e', 'h', 'T', 'd', 'H', 'n', 'o', 'g', 'L'};

    for (int i = 0;  flags[i]; i++){
        printf("-%cG \n", flags[i]);
        for (int j = i+1; flags[j]; j++){
            printf("-%c%cG \n", flags[i], flags[j]);
            // for (int k = j+1; flags[k]; k++){
            //     printf("-%c%c%c ", flags[i], flags[j], flags[k]);
            //     for (int mm = k+1; flags[mm]; mm++) {
            //         printf("-%c%c%c%c ", flags[i], flags[j], flags[k], flags[mm]);
            //     }
            // }
        }
    }
    return 0;
}
