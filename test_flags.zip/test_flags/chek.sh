make
From file
filename=flags_test.txt
declare -a myArray
Unix=(`cat "$filename"`)

##From string
#Unix=(-R);

Way=( '' /Users/mtsyfir / )
mkdir ../I_hope_u_have_not_this_dir_or_it_is_bad_4_y

for ((i = 0; i< ${#Unix[@]}; i++))
do
echo '\t' Start \"ls ${Unix[i]}\"
./uls ${Unix[i]} ${Way[0]}>../I_hope_u_have_not_this_dir_or_it_is_bad_4_y/test1
ls ${Unix[i]} ${Way[0]}>../I_hope_u_have_not_this_dir_or_it_is_bad_4_y/test2
diff ../I_hope_u_have_not_this_dir_or_it_is_bad_4_y/test1 ../I_hope_u_have_not_this_dir_or_it_is_bad_4_y/test2 > ../I_hope_u_have_not_this_dir_or_it_is_bad_4_y/diffresult
echo Difference for \"ls ${Unix[i]}\" is:
if [[ -s ../I_hope_u_have_not_this_dir_or_it_is_bad_4_y/diffresult ]];
then cat -e ../I_hope_u_have_not_this_dir_or_it_is_bad_4_y/diffresult;
else echo "All cool. No difference\n"; fi
done

nm -u uls > ../I_hope_u_have_not_this_dir_or_it_is_bad_4_y/forbiden_func.txt
if grep -q printf ../I_hope_u_have_not_this_dir_or_it_is_bad_4_y/$"forbiden_func.txt";
then echo There is printf
else echo There is NO printf
fi

rm -rf ../I_hope_u_have_not_this_dir_or_it_is_bad_4_y
